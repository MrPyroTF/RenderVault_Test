﻿(function () {
    const LOGIN_URL = "https://delightful-beach-088839910.centralus.6.azurestaticapps.net/";
    const SESSION_KEY = "rendervault_admin_session";
    const rawSession = localStorage.getItem(SESSION_KEY);

    function redirigirAlLoginPrincipal() {
        localStorage.removeItem(SESSION_KEY);
        window.location.replace(LOGIN_URL);
    }

    if (!rawSession) {
        redirigirAlLoginPrincipal();
        return;
    }

    try {
        const session = JSON.parse(rawSession);
        const esAdminValido =
            session &&
            (session.isAdmin === true ||
                session.adminId ||
                session.AdminId ||
                session.correo ||
                session.Correo ||
                session.nombreUsuario ||
                session.NombreUsuario);

        if (!esAdminValido) {
            redirigirAlLoginPrincipal();
            return;
        }

        window.RenderVaultAdmin = {
            session,
            logout: function () {
                localStorage.removeItem(SESSION_KEY);
                window.location.replace(LOGIN_URL);
            }
        };
    } catch (e) {
        redirigirAlLoginPrincipal();
    }
})();